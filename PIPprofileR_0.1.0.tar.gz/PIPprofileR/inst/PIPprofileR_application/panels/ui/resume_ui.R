resume <- fluidPage(
  h1("Summary"), 
    h2("Reference "), 
    uiOutput("refName_ui"), 
    uiOutput("refSize_ui"),
    uiOutput("refType_ui"),
    h2("Sequences information"), 
    dataTableOutput(outputId = "resumeQuery")
)